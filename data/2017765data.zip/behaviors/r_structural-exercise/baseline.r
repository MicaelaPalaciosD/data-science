rm(list = ls())
library(ggplot2)
library(dummies)

data <- read.csv("residuals.csv")

## import functions for EM estimation

source("EM_funcs.r")  # estimation when A constrained to be 1
source("EM_funcs_extended.r")  # estimation for A unconstrained


####################
## FORM COVARIATES
####################

cty <- dummy(data$cty)

type <- as.matrix(dummy(data$ceo_behavior >= 0.5))
colnames(type) <- c('type0', 'type1')

data$y <- data$residuals

data$developed <- 1 - as.integer(data$cty == 'in' | data$cty == 'br')
data$type1 <- type[,'type1']


####################
## HISTOGRAMS BY REGION - DEMEANED BY COUNTRY AVERAGE
####################

cty.means <- aggregate(data, by=list(data$cty), mean)[,c("Group.1", "y")]
data.temp <- merge(data, cty.means, by.x = 'cty', by.y = 'Group.1')
data.temp$y_demean <- data.temp$y.x - data.temp$y.y

theme_set(theme_gray(base_size = 18))

y0_temp <- data.temp$y_demean[data.temp$type1 == 0]
y1_temp <- data.temp$y_demean[data.temp$type1 == 1]


df <- data.frame(Productivity=c(y0_temp, y1_temp),
                 Type=c(rep('Managers', length(y0_temp)),
                        rep('Leaders', length(y1_temp))))

ggplot(df, aes(Productivity, fill = Type)) + geom_density(alpha = 0.5) + xlim(-2,2)
ggsave(paste('results/all.pdf', sep=""))

for(c in 0:1){

    y0_temp <- data.temp$y_demean[data.temp$type1 == 0 & data.temp$developed == c]
    y1_temp <- data.temp$y_demean[data.temp$type1 == 1 & data.temp$developed == c]

    df <- data.frame(Productivity=c(y0_temp, y1_temp),
                     Type=c(rep('Managers', length(y0_temp)),
                            rep('Leaders', length(y1_temp))))

    ggplot(df, aes(Productivity, fill = Type)) + geom_density(alpha = 0.5) + xlim(-2,2)
    ggsave(paste('results/developed', c, '.pdf', sep=""))
    
}

####################
## ESTIMATION WHEN ALL FIRMS HAVE SAME MISMATCH PROBABILITY
####################

mix <- as.matrix(rep(1, nrow(data)))

args <- list("y"=data$y, "types"=type, "cty_fe"=cty, "mixing"=mix, "N"=6, "Q"=ncol(mix))

## define starting values for EM algorithm

mu <- aggregate(data, by=list(type[,"type1"], data$cty), mean)
fe.start <- mu[mu$Group.1 == 0, 'y']

sd <- aggregate(data, by=list(type[,"type1"], data$cty), sd)
s0.start <- sd[sd$Group.1 == 0, 'y']
s1.start <- sd[sd$Group.1 == 1, 'y']
delta.start <- 0
A.start <- 0.2

samples <- 10
## number of runs of EM algorithm, starting from random starting values

### begin estimation ###

l.vec.1 <- c()
param.mat.1 <- matrix(NA, nrow = samples, ncol = 3*args$N + 1 + args$Q)
## contains parameters for case in which A constrained to be 1

l.vec.2 <- c()
param.mat.2 <- matrix(NA, nrow = samples, ncol = 3*args$N + 2 + args$Q)
## contains parameters for case in which A is unconstrainted and estimated

j <- 1
q.vec <- c()

while(j <= samples){

    q <- runif(1, 0, 1)
    
    test.1 <- EM_est(c(fe.start, s0.start, s1.start, delta.start,
                     rep(q, args$Q)), 10000, args)
    l.vec.1[j] <- test.1$llf
    param.mat.1[j,] <- test.1$params

    start.2 <- c(test.1$params[1:(3*args$N)], A.start, test.1$params[3*args$N+1],
                 test.1$params[3*args$N+2])
    ## the starting values for unconstrainted A are the parameter values estimated
    ## in the constrained case
    test.2 <- tryCatch(EM_est_extended(start.2, 10000, args),
                       error = function(err) paste("MY_ERROR:  ",err))
    if(length(test.2) > 1){
        q.vec[j] <- q
        l.vec.2[j] <- test.2$llf
        param.mat.2[j,] <- test.2$params
        cat("sample",j,"\n")
        j <- j + 1
    }
    
}


## choose parameters based on highest log-likelihood across EM runs

params.1 <- param.mat.1[which.max(l.vec.1),]
llf.1 <- max(l.vec.1)

params.2 <- param.mat.2[which.max(l.vec.2),]
llf.2 <- max(l.vec.2)

tstat <- 2*(llf.2 - llf.1)
pval_v1 <- format(pchisq(tstat, lower.tail=F, df=1), digits=3)
print(paste("p value for test of A=1 is", pval_v1))

### estimation with constraints on mismatch probability ###

start <- c(params.2[1:(3*args$N)], A.start, params.2[3*args$N + 2])

x1 <- optim(start, LLF_extended, gr=NULL, q=1,
            args=args, method = "BFGS", control=list(fnscale=-1, maxit=1000))
## constrain efficient match probablity q=1


tstat <- 2*(llf.2 - x1$value)
pval_v2 <- format(pchisq(tstat, lower.tail=F, df=1), digits=3)
print(paste("p value for test of q=1 is", pval_v2))

x0 <- optim(start, LLF_extended, gr=NULL, q=0,
            args=args, method = "BFGS", control=list(fnscale=-1, maxit=1000))
## constrain efficient match probablity q=0

tstat <- 2*(llf.2 - x0$value)
pval_v3 <- format(pchisq(tstat, lower.tail=F, df=1), digits=3)
print(paste("p value for test of q=0 is", pval_v3))

####################
## ESTIMATION WHEN MISMATCH PROBABILITY VARIES WITH DEVELOPMENT
####################

mix <- as.matrix(dummy(data$cty != 'br' & data$cty != 'in'))
colnames(mix) <- c('developing', 'developed')

args <- list("y"=data$y, "types"=type, "cty_fe"=cty, "mixing"=mix, "N"=6, "Q"=ncol(mix))

l.vec.3 <- c()
param.mat.3 <- matrix(NA, nrow = samples, ncol = 19 + args$Q)

for(j in 1:samples){

    test.3 <- EM_est(c(fe.start, s0.start, s1.start, delta.start, rep(q.vec[j], args$Q)), 10000, args)
    l.vec.3[j] <- test.3$llf
    param.mat.3[j,] <- test.3$params
    cat("sample",j,"\n")
    
}


params.3 <- param.mat.3[which.max(l.vec.3),]
llf.3 <- max(l.vec.3)

tstat <- 2*(llf.3 - llf.1)
pval_v4 <- format(pchisq(tstat, lower.tail=F, df=1), digits=3)


q <- round(tail(params.3, args$Q), digits=3)
delta <- round(params.3[3*args$N + 1], digits=3)
s <- c()
for(i in 1:args$Q){
    s[i] <- sum(args$types[args$mixing[, i] == 1, "type1"]) / sum(args$mixing[, i])
}
s <- round(s, digits=3)
phi <- round(s + (1-s)*(1-q), digits=3)
mismatch <- round(phi - s, digits=3)

temp1 <- "\\multicolumn{2}{c|}{Estimated Parameters}"
temp2 <- "\\multicolumn{3}{c}{Derived Parameters}"
temp3 <- '\\begin{tabular}{@{}c@{}}\\% firms \\\\ mismatched \\end{tabular}'

line0 <- paste(paste(c('', temp1, temp2), collapse=' & '), '\\\\', sep="")
line1 <- paste(paste(c('', '$\\Delta$', '$q$', '$\\widehat{s}$',
                       '$\\phi$', temp3), collapse=' & '), '\\\\ \\hline', sep="")
line2 <- paste(paste(c('low/middle income', delta, q[1], s[1], phi[1], mismatch[1]),
                     collapse=' & '), '\\\\', sep="")
line3 <- paste(c('high income', delta, q[2], s[2], phi[2], mismatch[2]), collapse=' & ')

fileConn <- file('results/results_development.tex', 'w')
writeLines('\\begin{tabular}[h]{c|cc|ccc}', con=fileConn)
writeLines(line0, con=fileConn)
writeLines(line1, con=fileConn)
writeLines(line2, con=fileConn)
writeLines(line3, con=fileConn)
writeLines('\\end{tabular}', con=fileConn)
close(fileConn)
