LLF_Q <- function(params, args, z){

    # expected complete data log-likelihood
    
    fe <- params[1:args$N]
    fe <- args$cty_fe %*% fe

    sd.0 <- exp(params[(args$N + 1):(2 * args$N)])
    sd.0 <- args$cty_fe %*% sd.0

    sd.1 <- exp(params[(2*args$N + 1):(3 * args$N)])
    sd.1 <- args$cty_fe %*% sd.1

    delta <- params[3*args$N + 1]

    p0 <- log(dnorm(args$y, fe, sd.0))
    p1 <- log(dnorm(args$y, fe + delta, sd.1))
    
    return(sum((1 - z) * p0) + sum(z * p1))

}


LLF <- function(params, q, args){

    # log-likelihood

    ql <- length(params) - args$Q + 1
    qh <- length(params)

    fe <- params[1:args$N]
    fe <- args$cty_fe %*% fe

    sd.0 <- exp(params[(args$N + 1):(2 * args$N)])
    sd.0 <- args$cty_fe %*% sd.0

    sd.1 <- exp(params[(2 * args$N + 1):(3 * args$N)])
    sd.1 <- args$cty_fe %*% sd.1

    delta <- params[3*args$N + 1]

    q <- args$mixing %*% q

    p0 <- (1 - q) * dnorm(args$y, fe, sd.0) + q * dnorm(args$y, fe + delta, sd.1)
    p1 <- dnorm(args$y, fe + delta, sd.1)
    
    return(sum(log(p0[args$types[,"type0"] == 1])) +
           sum(log(p1[args$types[,"type1"] == 1])))

}


EM_est <- function(params, max_iter, args){

    iter <- 1
    new_lik <- -99999999  # seed value for log-likelihood
    log.lik <- c()

    ql <- length(params) - args$Q + 1
    qh <- length(params)

    while(iter <= max_iter){

        ## compute distribution over latent assignments (E step)

        fe <- params[1:args$N]
        fe <- args$cty_fe %*% fe

        sd.0 <- params[(args$N + 1):(2*args$N)]
        sd.0 <- args$cty_fe %*% sd.0
        
        sd.1 <- params[(2*args$N + 1):(3*args$N)]
        sd.1 <- args$cty_fe %*% sd.1

        delta <- params[3*args$N + 1]

        q <- params[ql:qh]
        q <- args$mixing %*% q

        p0 <- log(1 - q) + log(dnorm(args$y, fe, sd.0))
        p1 <- log(q) + log(dnorm(args$y, fe + delta, sd.1))
        z <- exp(p1) / (exp(p0) + exp(p1))
        z[args$types[, "type1"] == 1] <- 1

        ###### uncomment to have perfect matching in developed countries
        ## z[args$mixing[, "developed"] == 1] <- 1
        
        ## update parameter values (M step)

        old_lik <- new_lik

        params_norm <- params[-(ql:qh)]  # we will compute mixing probs explicitly
        params_norm[(args$N + 1):(3*args$N)] <- log(params_norm[(args$N + 1):(3*args$N)])
    
        x <- optim(params_norm, LLF_Q, gr = NULL, args, z, 
                   method = "BFGS", control=list(fnscale=-1, maxit=1000))
 
        params <- x$par
        params[(args$N + 1):(3*args$N)] <- exp(params[(args$N + 1):(3*args$N)])

        mix_probs <- c()
        
        for(j in 1:ncol(args$mixing)){
            mix_probs <- c(mix_probs, mean(z[args$mixing[, j] == 1 & args$types[, "type0"] == 1]))
        }

        params[ql:qh] <- mix_probs

        new_lik <- LLF(x$par[-c(ql:qh)], mix_probs, args)
        
        if(new_lik < old_lik){
            cat("!!! ERROR AT ITERATION = ", iter, "\n")
            return(params)
        } else if(new_lik - old_lik < 1e-5){
            cat("convergence at iteration", iter, "\n")
            est <- list("llf"=new_lik, "params"=params, "z"=z)
            return(est)
        }

        iter <- iter + 1
        
    }

}
