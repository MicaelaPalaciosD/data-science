Running the file baseline.r will produce all results reported in section 5.1 of the paper.  residuals.csv is the input file for the structural model, and contains the CEO behavior index, productivity residual, and country for each CEO.  The results in results_development.tex, and p values output by the program, may differ slightly on each run of baseline.r since the EM algorithm may converge to slightly different parts of the parameter space on any given sequence of starting values.

Files run and verified on 
R version 3.4.0 (2017-04-21) -- "You Stupid Darkness"
Platform: x86_64-apple-darwin16.5.0 (64-bit)