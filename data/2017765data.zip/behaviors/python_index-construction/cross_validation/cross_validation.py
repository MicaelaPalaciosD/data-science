import topicmodels
import pandas as pd
from sklearn.model_selection import train_test_split
import numpy as np
import sys

ceo_data = pd.read_csv("../baseline_results/survey_response_data.csv",
                       low_memory=False)
ceo_data.set_index(['id'], inplace=True)
ceo_data = ceo_data[ceo_data.type != 'personal_family']
ceo_data = ceo_data[(ceo_data.level1 == 'interacting')]

agg_data = ceo_data.groupby(ceo_data.index).\
    agg({'all_combined': lambda x: ' '.join(x)})

test_size = 0.33  # 2/3-1/3 split of data into training and test
iters = int(sys.argv[1])
K_vals = sys.argv[2].split('-')
K_vals = [int(i) for i in K_vals]

'''
sys.argv[1]: the number of train/test splits to estimate
sys.argv[2]: the values of K to estimate, separate by hyphen,
i.e. 5-10-15-20 would estimate models of size 5, 10, 15, and 20
'''

results = np.zeros((len(K_vals), iters))

for i in range(iters):

    train, test = train_test_split(agg_data, test_size=test_size)

    docsobj_train = topicmodels.RawDocs(train.all_combined)
    docsobj_train.term_rank("tokens")
    docsobj_train.rank_remove("df", "tokens", int(30*(1-test_size)))

    docsobj_test = topicmodels.RawDocs(test.all_combined)
    docsobj_test.term_rank("tokens")
    docsobj_test.rank_remove("df", "tokens", int(30*test_size))

    for j, K in enumerate(K_vals):

        ldaobj_train = topicmodels.LDA.LDAGibbs(docsobj_train.tokens, K)
        ldaobj_train.set_priors(1.0, 0.1)
        ldaobj_train.sample(5000, 50, 100)

        queryobj = topicmodels.LDA.QueryGibbs(docsobj_test.tokens,
                                              ldaobj_train.token_key,
                                              ldaobj_train.tt)

        queryobj.dt = np.full((train.shape[0], queryobj.K, queryobj.samples),
                              1 / queryobj.K)
        # use uniform prior for out-of-sample observations

        results[j, i] = queryobj.perplexity().mean()

np.savetxt('output.csv', results, delimiter=',')
