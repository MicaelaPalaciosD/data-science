import sys
import topicmodels
import pandas as pd
import numpy as np

# READ IN AND PREPARE DATA AS FOR BASELINE RESULTS

ceo_data = pd.read_csv("../baseline_results/survey_response_data.csv",
                       low_memory=False)
ceo_data.set_index(['id'], inplace=True)
ceo_data = ceo_data[ceo_data.type != 'personal_family']
ceo_data = ceo_data[(ceo_data.level1 == 'interacting')]

agg_data = ceo_data.groupby(ceo_data.index).\
    agg({'all_combined': lambda x: ' '.join(x)})

docsobj = topicmodels.RawDocs(agg_data.all_combined)
docsobj.term_rank("tokens")
docsobj.rank_remove("df", "tokens", 30)

# FORM EMPIRICAL DISTRIBUTION OF ACTIVITIES IN THE DATA

ldaobj = topicmodels.LDA.LDAGibbs(docsobj.tokens, 2)
ldaobj.set_priors(1.0, 0.1)
unique, counts = np.unique(ldaobj.tokens, return_counts=True)
beta = np.array([c / 98347 for c in counts])

# SIMULATE PURE BEHAVIORS WITH K=2 WHEN ACTIVITIES DRAWN FROM EMPIRICAL
# DISTRIBUTION FOR ALL CEOS.

iters = int(sys.argv[1])  # number of iterations defined from command line

beta0_sim = np.zeros((ldaobj.V, iters))
beta1_sim = np.zeros((ldaobj.V, iters))

for i in range(iters):

    ldaobj = topicmodels.LDA.LDAGibbs(docsobj.tokens, 2)
    ldaobj.tokens = np.random.choice(654, 98347, p=beta)
    # simulate activities from empirical distribution
    ldaobj.sample(1, 2, 2)

    betas = ldaobj.tt_avg(False)
    beta0_sim[:, i] = betas[:, 0]
    beta1_sim[:, i] = betas[:, 1]

np.savetxt('beta0' + sys.argv[2] + '.csv', beta0_sim, delimiter=',')
np.savetxt('beta1' + sys.argv[2] + '.csv', beta1_sim, delimiter=',')
# sys.argv[2] useful for running script in parallel and writing different files
# to local directory.  Can set to '' otherwise.
