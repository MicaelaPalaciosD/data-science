import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

mpl.style.use('classic')  # use style defaults in matplotlib 1.x


def hellinger(x, y):

    cons = 1 / np.sqrt(2)
    diff = np.sqrt(x) - np.sqrt(y)

    return cons * np.sqrt(np.power(diff, 2).sum())


ldaobj = np.matrix(np.load('../baseline_results/baseline/\
K2_chain3/estobj.npy', encoding="latin1")).item(0)
ldaobj.samples_keep(100)
tt = ldaobj.tt_avg(False)

x = hellinger(tt[:, 0], tt[:, 1])

beta0 = np.genfromtxt('beta0.csv', delimiter=',')
beta1 = np.genfromtxt('beta1.csv', delimiter=',')

distances = np.zeros(1000)

for i in range(1000):
    distances[i] = hellinger(beta0[:, i], beta1[:, i])

bins = np.linspace(0, 1, 50)

fig = plt.figure()
plt.hist(distances, bins, alpha=0.5, cumulative=False)
plt.axvline(x, color='r', linewidth=2)
plt.xlabel('Hellinger Distances: Simulated (Blue) and Acutal (Red)')
plt.savefig("output.png")
