Files in the directory baseline_results allow the construction of the CEO behavior index.  The raw survey data is contained in survey_response_data.csv.  Each row of this file contains a description of a 15-minute chunk of CEO time.  The feature space is defined as the combination of underlying activity features, and each activity is described in this space in the column all_combined.

The CEO behavior index is constructed in two steps:

(1) The first requires running baseline_estimation.py.  This requires some packages that are part of the standard Python scientific stack, as well as topicmodels, whose code is available at https://github.com/alan-turing-institute/topic-modelling-tools and is described and illustrated at https://github.com/sekhansen/text-mining-tutorial.  The file estimates five different Markov chains based on the activity data, and stores the estimation objects in baseline_results/baseline.  It also produces a plot of the perplexity along each chain in baseline_results/perplexities.png.

(2) The user can choose which Markov chain to use to construct the index based on perplexities.  In this example, we use the third chain.  baseline_chain_selection.py takes a given chain, and outputs the CEO behavior index (in ceo_behavior_index.csv) as well as the the top activities in each pure behavior based on their probabilities (in pure_behaviors.csv).  In the STATA files, the CEO behavior index, called ceo_behavior, is the ceo_behavior0 column in ceo_behavior_index.csv.

Note that any given run of step (1) will not produce the exact same output since MCMC algorithms are stochastic.  For a given estimated chain, step (2) will produce identical output.

- baseline_plots.py produces descriptive plots as reported in the paper.
- margin_compare.py produces the comparison of the two pure behaviors reported in table 2 of the paper.
- tab_shares.py produces the comparison of actual vs estimated time shares reported in table B.3 of the paper.

Tables B.1 and B.2 are manually constructed from the output contained in pure_behaviors.csv.

__________________________________________________________________________________

Files in the directory alternative_measures contain estimation files for three different unsupervised learning algorims.  

- non_param.py implements k-means clustering and principal components analysis.  
- mixture_model.py estimates a two-element multinomial mixture model, and again requires topicmodels.

__________________________________________________________________________________

Files in the directory bootstrap relate to the test reported in appendix B.2.

- bootstrap.py estimates activity data randomly drawn from the empirical frequency distribution.
- dist_comp.py takes the output of the bootstrap simulations, and produces the comparison plot in figure B.1 of the paper.

__________________________________________________________________________________

Files in the directory cross_validation relate to the cross validation procedure described in appendix D.2.7.

- cross_validation.py randomly splits the activity data into training tests for estimation and test sets for validation.  The file allows the user to define the number of such splits to compute, as well as a sequence of values for K.

- perplexity.csv organizes the output of cross_validation.py, and reports average perplexity across ten splits.  Figure D.3 in the paper is a plot of column L (“Average”) of this file.

__________________________________________________________________________________

All files run and verified on Python 3.7.1 (default, Dec 14 2018, 13:28:58).