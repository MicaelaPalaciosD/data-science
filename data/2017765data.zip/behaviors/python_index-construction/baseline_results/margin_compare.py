'''
This file compares the marginal distributions for different
pure behaviors as reported in Table 2 of the paper
'''

import pandas as pd
import numpy as np
import plot_funcs


def margin(tt, K, fn, dim=None):

    if dim:
        df = tt.groupby(list(map(fn, tt.index, [dim]*tt.shape[0]))).agg(sum)
    else:
        df = tt.groupby(list(map(fn, tt.index))).agg(sum)

    df = df / df.sum(0)
    # this is redundant when tt is probability matrix, put in for counts

    df.columns = ['PB' + str(i) for i in range(K)]  # PB = pure behavior

    return df


########################################

ldaobj = np.matrix(np.load('./baseline/K2_chain3/estobj.npy',
                           encoding="latin1")).item(0)
type_map = {1: 2, 2: 1}
samples = 100

temp = (ldaobj.sampled_topics+1)*10
for old, new in type_map.items():
    np.place(temp, temp == 10*old, new)
ldaobj.set_sampled_topics(temp-1)

ldaobj.samples_keep(samples)

dt = ldaobj.dt_avg(False)
dt = dt.mean(axis=0)
tt = pd.DataFrame(ldaobj.tt_avg(False))

keys = list(ldaobj.token_key.keys())
values = list(ldaobj.token_key.values())
key_index = [keys[values.index(v)] for v in range(ldaobj.V)]

key_index = [x.replace('1hrplus', '1hr+') for x in key_index]
key_index = [x.replace('two_plus_ppl', 'size2+') for x in key_index]
key_index = [x.replace('one_ppl', 'size1') for x in key_index]
key_index = [x.replace('associations', 'assocns') for x in key_index]
key_index = [x.replace('business_meal', 'bus_meal') for x in key_index]

tt.index = key_index

K = ldaobj.K

# COMPARISON OF ACTIVITY TYPES

type_margin = margin(tt, K, plot_funcs.how_agg, 1)

temp = type_margin.loc['site_visit', 'PB1'] / \
        type_margin.loc['site_visit', 'PB0']

print("Comparison of Plant Visits =", temp)

comm_types = ['conference_call', 'phone_call', 'video_conference']
comm_margin = type_margin.loc[comm_types].sum()

temp = comm_margin.loc['PB1'] / \
        comm_margin.loc['PB0']

print("Comparison of Communication =", temp)

# COMPARISON OF INSIDERS/OUTSIDERS

ins_out_margin = margin(tt, K, plot_funcs.who_agg)
temp = ins_out_margin['PB1'] / ins_out_margin['PB0']
print("Comparison of Just Outsiders =", temp.loc['out_alone'])
print("Comparison of Insiders and Outsiders =", temp.loc['ins_out'])

# COMPARISON OF FUNCTIONS

out = pd.DataFrame(index=plot_funcs.out_funcs,
                   columns=['PB' + str(i) for i in range(K)])

for f in plot_funcs.out_funcs:
    out.loc[f, :] = margin(tt, K, plot_funcs.who_func, f).loc[f + 'Y'].values

temp = out['PB1'] / out['PB0']

print("Comparison of Suppliers =", temp.loc['suppliers'])

ins = pd.DataFrame(index=plot_funcs.ins_funcs,
                   columns=['PB' + str(i) for i in range(K)])

for f in plot_funcs.ins_funcs:
    ins.loc[f, :] = margin(tt, K, plot_funcs.who_func, f).loc[f + 'Y'].values

temp = ins['PB1'] / ins['PB0']

print("Comparison of Production =", temp.loc['production'])

c_suite = ['groupcom', 'bunits']
c_suite_margin = ins.loc[c_suite].sum()

temp = c_suite_margin['PB1'] / c_suite_margin['PB0']

print("Comparison of C-suite =", temp)

# COMPARISON OF MULTI-FUNCTION

df = pd.DataFrame(index=['Nfunc>1', 'size2+', 'planned'],
                  columns=['PB' + str(i) for i in range(K)])

df.loc['planned'] = margin(tt, K, plot_funcs.how_agg, 3).\
                    loc['planned'].values
df.loc['size2+'] = margin(tt, K, plot_funcs.how_agg, 4).\
                   loc['size2+'].values
df.loc['Nfunc>1'] = margin(tt, K, plot_funcs.N_funcs).loc['Nfunc>1'].values

temp = df['PB1'] / df['PB0']

print("Comparison of Multi-Function =", temp.loc['Nfunc>1'])
