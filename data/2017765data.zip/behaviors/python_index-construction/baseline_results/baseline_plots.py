import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np

mpl.style.use('classic')  # use style defaults in matplotlib 1.x

path = 'baseline/K2_chain3'
ldaobj = np.matrix(np.load(path + '/estobj.npy', encoding='latin1')).item(0)
ldaobj.samples_keep(100)
tt = ldaobj.tt_avg(False)
tt = np.fliplr(tt)  # flip columns so that pure behavior 1 is the leader

# CODE FOR FIGURE 3 IN PAPER

fig = plt.figure()
plt.xlim(-5, 655)
plt.ylim(0, 0.06)
ax = plt.plot(tt[tt[:, 0].argsort()[::-1], 0], linewidth=2.5,
              linestyle='dashed', label='Pure Behavior 0', color='r')
plt.plot(tt[tt[:, 0].argsort()[::-1], 1], label='Pure Behavior 1', color='b')
plt.legend(loc="upper right")
plt.savefig("type0.png")

# CODE FOR FIGURE 4 IN PAPER

dt = ldaobj.dt_avg(False)

bins = np.linspace(0, 1, 50)

fig = plt.figure()
plt.hist(dt[:, 0], bins, alpha=0.5, cumulative=False)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.savefig("behavior_pdf.png")

fig = plt.figure()
plt.hist(dt[:, 0], bins, alpha=0.5, cumulative=True, density=True)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.savefig("behavior_cdf.png")
