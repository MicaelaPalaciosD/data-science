import pandas as pd
import numpy as np
import topicmodels

# READ IN DATA AND SELECT SAMPLE - AS IN BASELINE

ceo_data = pd.read_csv("survey_response_data.csv", low_memory=False)
ceo_data.set_index(['id'], inplace=True)
ceo_data = ceo_data[ceo_data.type != 'personal_family']
ceo_data = ceo_data[(ceo_data.level1 == 'interacting')]

agg_data = ceo_data.groupby(ceo_data.index).\
    agg({'all_combined': lambda x: ' '.join(x)})

docsobj = topicmodels.RawDocs(agg_data.all_combined)
docsobj.term_rank("tokens")
docsobj.rank_remove("df", "tokens", 30)
# remove activities in fewer than 30 CEOs' diaries


# COMPUTE CEO BEHAVIOR INDEX BASED ON SELECTED CHAIN

path = 'baseline/K2_chain3'

ldaobj = np.matrix(np.load(path + '/estobj.npy', encoding='latin1')).item(0)
# npy file created with python2, replication files in python3
# encoding needed to avoid import error
ldaobj.samples_keep(100)  # keep last 100 samples from Markov chain
index = agg_data.index

ldaobj.topic_content(20, './pure_behaviors.csv')
dt = ldaobj.dt_avg(False)
ceo_behavior_index = pd.DataFrame(index=index)
for i in range(ldaobj.K):
    ceo_behavior_index['ceo_behavior' + str(i)] = dt[:, i]
    ceo_behavior_index.to_csv('./ceo_behavior_index.csv', index=True)
