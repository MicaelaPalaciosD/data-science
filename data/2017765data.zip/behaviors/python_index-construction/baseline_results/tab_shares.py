'''
This file tabulates the average share of CEO time in various activites,
both according to the actual data and according to shares estimated by
the two-pure-behavior model used in the baseline estimates.
'''

import pandas as pd
import numpy as np
import plot_funcs


def var_share(df, col):

    """
    compute average share of time for CEOs in data
    """

    temp = pd.crosstab(df.index, df[col])
    temp = temp.apply(lambda r: r/r.sum(), axis=1)
    return temp.mean(axis=0).sort_values(ascending=False)


def margin(tt, K, fn, dim=None):

    if dim:
        df = tt.groupby(list(map(fn, tt.index, [dim]*tt.shape[0]))).agg(sum)
    else:
        df = tt.groupby(list(map(fn, tt.index))).agg(sum)

    df = df / df.sum(0)
    # this is redundant when tt is probability matrix, put in for counts

    df.columns = ['PB' + str(i) for i in range(K)]  # PB = pure behavior

    return df


########################################

ldaobj = np.matrix(np.load('./baseline/K2_chain3/estobj.npy',
                           encoding="latin1")).item(0)
type_map = {1: 2, 2: 1}
samples = 100

temp = (ldaobj.sampled_topics+1)*10
for old, new in type_map.items():
    np.place(temp, temp == 10*old, new)
ldaobj.set_sampled_topics(temp-1)

ldaobj.samples_keep(samples)

dt = ldaobj.dt_avg(False)
dt = dt.mean(axis=0)
tt = pd.DataFrame(ldaobj.tt_avg(False))

keys = list(ldaobj.token_key.keys())
values = list(ldaobj.token_key.values())
key_index_original = [keys[values.index(v)] for v in range(ldaobj.V)]

key_index = [x.replace('1hrplus', '1hr+') for x in key_index_original]
key_index = [x.replace('two_plus_ppl', 'size2+') for x in key_index]
key_index = [x.replace('one_ppl', 'size1') for x in key_index]

tt.index = key_index

########################################

ceo_data = pd.read_csv("survey_response_data.csv", low_memory=False)
ceo_data.set_index(['id'], inplace=True)
ceo_data = ceo_data[(ceo_data.level1 == 'interacting')]

ceo_data['n_ins_funcs'] = ceo_data.loc[:, 'finance':'groupcom'].sum(axis=1)
ceo_data['n_out_funcs'] = ceo_data.loc[:, 'clients':'pemployee'].sum(axis=1)

ceo_data['ins_alone'] = 0
ceo_data.loc[(ceo_data.n_ins_funcs > 0) & (ceo_data.n_out_funcs == 0),
             'ins_alone'] = 1

ceo_data['out_alone'] = 0
ceo_data.loc[(ceo_data.n_ins_funcs == 0) & (ceo_data.n_out_funcs > 0),
             'out_alone'] = 1

ceo_data['ins_out'] = 0
ceo_data.loc[(ceo_data.n_ins_funcs > 0) & (ceo_data.n_out_funcs > 0),
             'ins_out'] = 1

'''
there are a non-trivial amount of observations for which activity data are
missing.  in the way we report the marginals, constructed in plot_funcs,
these missing values are implicitly set to ins_out (it is the else category
in an if...else if...else statement.  so to maintain consistency with the
raw data we replace missing with ins_out.  this is done ONLY to maintain
comparability with the LDA marginals to compare raw vs fitted.
'''

ceo_data['temp'] = ceo_data.ins_alone + ceo_data.out_alone + ceo_data.ins_out
ceo_data.loc[ceo_data.temp == 0, 'ins_out'] = 1

ceo_data['Nfuncs'] = ceo_data['n_ins_funcs'] + ceo_data['n_out_funcs']

ceo_data['2funcs+'] = 0
ceo_data.loc[ceo_data.Nfuncs > 1, '2funcs+'] = 1

ceo_data = ceo_data[ceo_data.all_combined.isin(key_index_original)]

ceo_data = ceo_data.rename(columns={'type': 'Type', 'F_duration': 'Duration',
                                    'F_planned': 'Planned',
                                    'F_participants': 'Participants'})

########################################

tab_index = ['Meeting', 'Communications', 'Site Visit',
             'Insiders', 'Outsiders', 'Insiders & Outsiders',
             'Production', 'Marketing', 'C-suite', 'Clients', 'Suppliers',
             'Consultants', 'Planned', '>1 Hour', '2 People or More',
             '2 Functions or More']

df_table = pd.DataFrame(index=tab_index, columns=['Raw', 'Estimated'])

##########

temp_raw = var_share(ceo_data, 'Type')

df_table.loc['Meeting', 'Raw'] = temp_raw.loc['meeting']
df_table.loc['Communications', 'Raw'] =\
    temp_raw.loc[['phone_call', 'conference_call', 'video_conference']].sum()
df_table.loc['Site Visit', 'Raw'] = temp_raw.loc['site_visit']

temp_est = margin(tt, 2, plot_funcs.how_agg, 1)['PB0'] * dt[0] +\
    margin(tt, 2, plot_funcs.how_agg, 1)['PB1'] * dt[1]

df_table.loc['Meeting', 'Estimated'] = temp_est.loc['meeting']
df_table.loc['Communications', 'Estimated'] =\
    temp_est.loc[['phone_call', 'conference_call', 'video_conference']].sum()
df_table.loc['Site Visit', 'Estimated'] = temp_est.loc['site_visit']

##########

df_table.loc['Production', 'Raw'] = var_share(ceo_data, 'production')[1]
df_table.loc['Marketing', 'Raw'] = var_share(ceo_data, 'mkting')[1]
df_table.loc['C-suite', 'Raw'] = var_share(ceo_data, 'bunits')[1] + \
                                var_share(ceo_data, 'groupcom')[1]

df_table.loc['Clients', 'Raw'] = var_share(ceo_data, 'clients')[1]
df_table.loc['Suppliers', 'Raw'] = var_share(ceo_data, 'suppliers')[1]
df_table.loc['Consultants', 'Raw'] = var_share(ceo_data, 'consultants')[1]


def func_agg(func):

    temp = margin(tt, 2, plot_funcs.who_func, func).values
    return temp[1, 0] * dt[0] + temp[1, 1] * dt[1]


df_table.loc['Production', 'Estimated'] = func_agg('production')
df_table.loc['Marketing', 'Estimated'] = func_agg('mkting')
df_table.loc['C-suite', 'Estimated'] = func_agg('bunits') + \
                                       func_agg('groupcom')

df_table.loc['Clients', 'Estimated'] = func_agg('clients')
df_table.loc['Suppliers', 'Estimated'] = func_agg('suppliers')
df_table.loc['Consultants', 'Estimated'] = func_agg('consultants')

##########

df_table.loc['Insiders', 'Raw'] = var_share(ceo_data, 'ins_alone')[1]
df_table.loc['Outsiders', 'Raw'] = var_share(ceo_data, 'out_alone')[1]
df_table.loc['Insiders & Outsiders', 'Raw'] = var_share(ceo_data, 'ins_out')[1]

temp = margin(tt, 2, plot_funcs.who_agg)

df_table.loc['Insiders', 'Estimated'] =\
    temp.loc['ins_alone', 'PB0'] * dt[0] + temp.loc['ins_alone', 'PB1'] * dt[1]

df_table.loc['Outsiders', 'Estimated'] =\
    temp.loc['out_alone', 'PB0'] * dt[0] + temp.loc['out_alone', 'PB1'] * dt[1]

df_table.loc['Insiders & Outsiders', 'Estimated'] =\
    temp.loc['ins_out', 'PB0'] * dt[0] + temp.loc['ins_out', 'PB1'] * dt[1]

##########

df_table.loc['>1 Hour', 'Raw'] = var_share(ceo_data, 'Duration')['1hrplus']
df_table.loc['Planned', 'Raw'] = var_share(ceo_data, 'Planned')['planned']
df_table.loc['2 People or More'] =\
    var_share(ceo_data, 'Participants')['two_plus_ppl']

temp = margin(tt, 2, plot_funcs.how_agg, 2)
df_table.loc['>1 Hour', 'Estimated'] =\
    temp.loc['1hr+', 'PB0'] * dt[0] + temp.loc['1hr+', 'PB1'] * dt[1]

temp = margin(tt, 2, plot_funcs.how_agg, 3)
df_table.loc['Planned', 'Estimated'] =\
    temp.loc['planned', 'PB0'] * dt[0] + temp.loc['planned', 'PB1'] * dt[1]

temp = margin(tt, 2, plot_funcs.how_agg, 4)
df_table.loc['2 People or More', 'Estimated'] =\
    temp.loc['size2+', 'PB0'] * dt[0] + temp.loc['size2+', 'PB1'] * dt[1]

##########

df_table.loc['2 Functions or More', 'Raw'] = var_share(ceo_data, '2funcs+')[1]

temp = margin(tt, 2, plot_funcs.N_funcs)
df_table.loc['2 Functions or More', 'Estimated'] =\
    temp.loc['Nfunc>1', 'PB0'] * dt[0] + temp.loc['Nfunc>1', 'PB1'] * dt[1]

df_table = df_table.astype(dtype=np.float64)
df_table = df_table.round(3)

df_table.to_csv('tab_shares_raw_estimated.csv')
