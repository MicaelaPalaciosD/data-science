import pandas as pd
import numpy as np
import topicmodels  # pip install topic-modelling-tools
import matplotlib.pyplot as plt


def chain_out(docsobj, K, path):

    '''
    docsobj: object containing diary information
    K: number of behaviors to estimate
    path: directory to which output is written
    '''

    ldaobj = topicmodels.LDA.LDAGibbs(docsobj.tokens, K)
    ldaobj.set_priors(1.0, 0.1)
    ldaobj.sample(10000, 50, 160)
    # 10k burnin iterations, 160 samples collected thereafter with
    # 50 thinning interval
    np.save(path + '/estobj', ldaobj)

    return 0


# READ IN DATA AND SELECT SAMPLE

ceo_data = pd.read_csv("survey_response_data.csv", low_memory=False)
ceo_data.set_index(['id'], inplace=True)
ceo_data = ceo_data[ceo_data.type != 'personal_family']
ceo_data = ceo_data[(ceo_data.level1 == 'interacting')]

agg_data = ceo_data.groupby(ceo_data.index).\
    agg({'all_combined': lambda x: ' '.join(x)})

docsobj = topicmodels.RawDocs(agg_data.all_combined)
docsobj.term_rank("tokens")
docsobj.rank_remove("df", "tokens", 30)
# remove activities in fewer than 30 CEOs' diaries


# PERFORM GIBBS SAMPLING

temp = chain_out(docsobj, 2, './baseline/K2_chain1')
temp = chain_out(docsobj, 2, './baseline/K2_chain2')
temp = chain_out(docsobj, 2, './baseline/K2_chain3')
temp = chain_out(docsobj, 2, './baseline/K2_chain4')
temp = chain_out(docsobj, 2, './baseline/K2_chain5')
# these local directories must all exist to write the output


# COMPUTE PERPLEXITY OF DIFFERENT CHAINS

perplexity = pd.DataFrame(index=range(2050, 10050, 50))
for i in range(1, 6):
    temp1 = np.load('baseline/K2_chain' + str(i) + '/estobj.npy',
                    encoding='latin1')
    temp = np.matrix(temp1).item(0)
    perplexity['chain' + str(i)] = temp.perplexity()
perplexity.plot()
plt.savefig('baseline/perplexities.png')
