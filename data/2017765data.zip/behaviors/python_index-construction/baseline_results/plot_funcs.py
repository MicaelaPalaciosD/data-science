ins_funcs = set(['finance', 'mkting', 'production', 'strategy',
                 'hr', 'bunits', 'admin', 'board', 'coo', 'cao',
                 'legal', 'groupcom'])

out_funcs = set(['clients', 'suppliers', 'banks', 'investors',
                 'lawyers', 'consultants', 'govoff', 'compts',
                 'assocns', 'pemployee'])


def drop(feature_vec, i, drop_list):

    """
    indicator for dropping observation from style if dimension i
    contains string in drop_list dimensions 0-4 precede string 'zzzz',
    dimension 5 proceeds it
    """

    feature_split = feature_vec.split('zzzz')

    if i < 5:
        how_features = feature_split[0].split('__')
        if how_features[i] in drop_list:
            return False
        else:
            return True
    elif i == 5:
        if feature_split[1] in drop_list:
            return False
        else:
            return True


def how_agg(feature_vec, i):

    feature_split = feature_vec.split('zzzz')
    how_features = feature_split[0].split('__')
    return how_features[i]


def who_func(feature_vec, func):

    feature_split = feature_vec.split('zzzz')
    if func in feature_split[1]:
        return func + 'Y'
    else:
        return func + 'N'


def who_agg(feature_vec):

    feature_split = feature_vec.split('zzzz')

    funcs = set(feature_split[1].split('_'))

    if ins_funcs.intersection(funcs) and not out_funcs.intersection(funcs):
        return 'ins_alone'
    elif out_funcs.intersection(funcs) and not ins_funcs.intersection(funcs):
        return 'out_alone'
    else:
        return 'ins_out'


def N_funcs(feature_vec):

    """
    count number of functions
    """

    feature_split = feature_vec.split('zzzz')
    N = len(feature_split[1].split('_'))

    if N > 1:
        return 'Nfunc>1'
    else:
        return 'Nfunc=1'
