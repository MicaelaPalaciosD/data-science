Files in the directory baseline_results reproduce the regressions tables in the paper "CEO Behavior and Firm Performance" by Bandiera, Hansen, Prat and Sadun.

All files run and verified on Stata 15 (February 2019).
The do file _CEObehavior.do reproduces each of the figures and tables included in the paper (main text and online appendix). 

The tables are built using data from 7 datasets, detailed below:
- Xsectional_selection.dta examines the differences between firms included in the sampling frame and those that returned a complete time use survey
- shares.dta provides the shares of time spent by the CEOs across different types of activities. These are derived by aggregating activity level data for each CEO at the week level.
- Xsectional_week.dta provides the cross-sectional data correlating the CEO behavior index and firm and CEO level characteristics. Please refer to the CEO behavior index construction files for details on the ceo_behavior variable.
- Accounts_matched_yearly.dta provides the CEO behavior index matched with yearly company level financial data in the 3 years interval around the interview year. The financial data is drawn from Orbis for all countries except India. Financial data for companies located in India is drawn from Prowess.
- Accounts_matched_collapsed.dta provides the CEO behavior index matched with company level financial data in the 3 years interval around the interview year, averaged across all years included in the interval.
- Accounts_matched_collapsed_profits.dta provides the CEO behavior index matched with company level financial data in the 3 years interval around the interview year, averaged across all years included in the interval and for the sample of firms providing profit data.
- Accounts_matched_beforeafter.dta provides the CEO behavior index matched with company level financial data in the 5 years interval before and after the CEO is appointed.

